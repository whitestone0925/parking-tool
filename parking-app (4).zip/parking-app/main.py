import os
import json
import re
import base64
from typing import Optional
import anthropic
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse

app = FastAPI()

HTML_CONTENT = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "index.html"), encoding="utf-8").read()

def get_client():
    return anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse(content=HTML_CONTENT)

@app.post("/api/analyze-floorplan")
async def analyze_floorplan(
    file: Optional[UploadFile] = File(None),
    demo: Optional[str] = Form(None),
    extra_instruction: Optional[str] = Form(None)
):
    extra = extra_instruction or ""
    prompt = (
        "コインパーキング設計の専門家として図面を解析し、以下のJSONのみ返してください。"
        + extra
        + '\n{"area_total":0,"area_effective":0,"shape":"rect","road_directions":1,'
        '"road_width":0,"slots_recommended":0,"slots_max":0,"sqm_per_slot":0,'
        '"layout_type":"parallel","obstacles":"なし",'
        '"confidence":{"area":"high","road":"high","slots":"high","shape":"high","obstacles":"high"},'
        '"evidence":"解析根拠を記載","warnings":"",'
        '"checks":['
        '{"label":"接道幅員3.5m以上","status":"ok","note":""},'
        '{"label":"有効面積20sqm/台","status":"ok","note":""},'
        '{"label":"入出庫動線確保","status":"ok","note":""},'
        '{"label":"精算機スペース","status":"ok","note":""},'
        '{"label":"照明設置余地","status":"ok","note":""},'
        '{"label":"障害物リスク","status":"ok","note":""},'
        '{"label":"排水勾配確保","status":"ok","note":""}]}'
    )
    try:
        client = get_client()
        if file and file.filename:
            contents = await file.read()
            b64 = base64.standard_b64encode(contents).decode("utf-8")
            mime = file.content_type or "image/jpeg"
            msg = client.messages.create(
                model="claude-opus-4-5", max_tokens=1500,
                messages=[{"role": "user", "content": [
                    {"type": "image", "source": {"type": "base64", "media_type": mime, "data": b64}},
                    {"type": "text", "text": prompt}
                ]}]
            )
        else:
            demo_prompt = "東京都内250sqm角地（長方形、接道2方向、幅員6m）の想定データとして " + prompt
            msg = client.messages.create(
                model="claude-opus-4-5", max_tokens=1500,
                messages=[{"role": "user", "content": demo_prompt}]
            )
        text = msg.content[0].text
        match = re.search(r"\{[\s\S]+\}", re.sub(r"```json|```", "", text).strip())
        data = json.loads(match.group(0)) if match else {}
        return JSONResponse(content={"success": True, "data": data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/market-research")
async def market_research(body: dict):
    address = body.get("address", "東京都内")
    area = body.get("area", 300)
    slots = body.get("slots", 10)
    prompt = (
        f"駐車場市場調査。所在地:{address} 面積:{area}sqm {slots}台規模。"
        "JSONのみ返してください:\n"
        '{"weekday_day":{"min":200,"max":300},"weekday_night":{"min":100,"max":200},'
        '"holiday_day":{"min":300,"max":400},"recommended_rate":200,"competitors_500m":5,'
        '"demand_level":"中","demand_reason":"周辺に商業施設あり",'
        '"market_summary":"需要は安定している","max_daily":2400}'
    )
    try:
        client = get_client()
        msg = client.messages.create(
            model="claude-opus-4-5", max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        text = msg.content[0].text
        match = re.search(r"\{[\s\S]+\}", re.sub(r"```json|```", "", text).strip())
        data = json.loads(match.group(0)) if match else {}
        return JSONResponse(content={"success": True, "data": data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/finance")
async def finance(body: dict):
    slots = body.get("slots", 10)
    rate = body.get("rate", 200)
    address = body.get("address", "東京都内")
    prompt = (
        f"収支試算。台数:{slots}台 料金:{rate}円/30分 所在地:{address}。"
        "JSONのみ:\n"
        '{"monthly_revenue":0,"monthly_mgmt":0,"monthly_lease":0,"monthly_electric":0,'
        '"monthly_tax":0,"monthly_total_cost":0,"monthly_profit":0,"annual_profit":0,'
        '"initial_investment":0,"payback_months":0,"yield_rate":0,"comment":"収支コメント"}'
    )
    try:
        client = get_client()
        msg = client.messages.create(
            model="claude-opus-4-5", max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        text = msg.content[0].text
        match = re.search(r"\{[\s\S]+\}", re.sub(r"```json|```", "", text).strip())
        data = json.loads(match.group(0)) if match else {}
        return JSONResponse(content={"success": True, "data": data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/proposal")
async def proposal(body: dict):
    address = body.get("address", "東京都内")
    area = body.get("area", 300)
    slots = body.get("slots", 10)
    rate = body.get("rate", 200)
    monthly_profit = body.get("monthly_profit", 0)
    annual_profit = body.get("annual_profit", 0)
    yield_rate = body.get("yield_rate", 0)
    payback_months = body.get("payback_months", 0)
    prompt = (
        f"営業提案資料。{address} {area}sqm {slots}台 {rate}円/30分 "
        f"月利益{monthly_profit}円 年利益{annual_profit}円 利回り{yield_rate}% 回収{payback_months}ヶ月。"
        "JSONのみ:\n"
        '{"slides":['
        '{"num":1,"title":"表紙","headline":"コインパーキング設置のご提案","body":"","key_numbers":[]},'
        '{"num":2,"title":"現状分析","headline":"","body":"","key_numbers":[]},'
        '{"num":3,"title":"提案概要","headline":"","body":"","key_numbers":[]},'
        '{"num":4,"title":"レイアウト計画","headline":"","body":"","key_numbers":[]},'
        '{"num":5,"title":"市場調査","headline":"","body":"","key_numbers":[]},'
        '{"num":6,"title":"収支試算","headline":"","body":"","key_numbers":[]},'
        '{"num":7,"title":"まとめ","headline":"","body":"","key_numbers":[]}]}'
    )
    try:
        client = get_client()
        msg = client.messages.create(
            model="claude-opus-4-5", max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        text = msg.content[0].text
        match = re.search(r"\{[\s\S]+\}", re.sub(r"```json|```", "", text).strip())
        data = json.loads(match.group(0)) if match else {}
        return JSONResponse(content={"success": True, "data": data})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
